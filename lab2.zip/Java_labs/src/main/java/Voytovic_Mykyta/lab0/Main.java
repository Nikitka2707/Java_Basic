package Voytovic_Mykyta.lab0;

/**
 *Hello world!
 *
 */
public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Hello world!");
    }
}